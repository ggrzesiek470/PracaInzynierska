package com.chess;

import com.chess.gui.Table;


public class JChess {
    public static void main(String[] args) {
        Table.get().show();
    }
}